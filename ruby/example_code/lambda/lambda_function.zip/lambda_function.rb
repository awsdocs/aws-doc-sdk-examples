def lambda_handler(event:, context:)
  # bucket = event["Records"][0]["s3"]["bucket"]["name"]
  # key = event["Records"][0]["s3"]["object"]["key"]
  # s3 = Aws::S3::Object.new(bucket, key)
  # type = s3.content_type
  # puts "CONTENT TYPE: #{type}"
  puts "Hello world"
end
