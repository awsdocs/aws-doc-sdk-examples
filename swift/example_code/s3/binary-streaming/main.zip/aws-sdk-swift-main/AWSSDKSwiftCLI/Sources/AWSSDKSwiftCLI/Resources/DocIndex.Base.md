# ``AWSSDKForSwift``

A pure-Swift SDK for accessing all published AWS services.

## Overview

This SDK is open-source.  Code is available on Github [here](https://github.com/awslabs/aws-sdk-swift).
