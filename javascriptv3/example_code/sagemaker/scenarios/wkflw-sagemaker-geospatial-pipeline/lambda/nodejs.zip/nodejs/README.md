# AWS Lambda layer for AWS SDK SageMaker
Zip the contents of this folder and upload the zip as a Lambda layer.